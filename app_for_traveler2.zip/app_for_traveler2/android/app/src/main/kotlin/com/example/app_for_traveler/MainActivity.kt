package com.example.app_for_traveler

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
